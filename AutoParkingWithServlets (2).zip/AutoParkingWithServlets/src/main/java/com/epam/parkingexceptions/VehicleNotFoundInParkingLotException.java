package com.epam.parkingexceptions;
/** exception when vehicle number searched for is not found in the parking lot.
 * @author Rithika_Mamidi
 */
public class VehicleNotFoundInParkingLotException extends Exception {
    /** exception when vehicle number searched for
     *  is not found in the parking lot.
     * @param exception exception string
     */
    public VehicleNotFoundInParkingLotException(final String exception) {
        super(exception);
    }

}
