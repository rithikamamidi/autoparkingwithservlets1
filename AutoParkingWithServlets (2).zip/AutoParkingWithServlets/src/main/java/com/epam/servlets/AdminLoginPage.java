package com.epam.servlets;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.services.Admin;
/** web servlet.
 * @author Rithika_Mamidi
 */
@WebServlet(urlPatterns = "/adminLogin")
public class AdminLoginPage extends HttpServlet {
    /** displays the login page to admin.
     */
    @Override
    protected void doGet(final HttpServletRequest request,
            final HttpServletResponse response)
            throws IOException, ServletException {
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.print("<title>Admin login page</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2> <center>Hello admin! Enter your details</center></h2>");
        out.println("<form action='/adminLogin' method='post'>");
        out.println("<center><table>"
        		+ "<tr>"
        		+ "<td>Name:</td>"
        		+ "<td><input type='text' name='username' value=''/></td><br/>"
        		+ "</tr><tr/><tr/>"
        		+ "<tr>"
        		+ "<td>Password:</td>"
        		+ "<td><input type='password' name='password' value=''/></td><br/>"
        		+ "</tr><tr/><tr/>"
        		+ "<tr>"
        		+ "<td align='center' colspan='2'><input type='submit' value='Login'/></td>"
        		+ "</tr>"
        		+ "</table></center>");
        
    }
    @Override
    protected void doPost(final HttpServletRequest request,
    		final HttpServletResponse response) 
    				throws IOException, ServletException {
    	Admin admin = new Admin("admin", "admin");
    	String userName = request.getParameter("username").trim();
    	String password = request.getParameter("password").trim();
    	if (userName.equals(admin.getUserName()) && password.equals(admin.getPassword())) {
    		response.sendRedirect("choices");
    	}
    }

}
