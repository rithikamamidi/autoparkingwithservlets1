package com.epam.servlets;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.services.Park;
import com.epam.services.Slot;
import com.epam.services.TransactionOperations;
import com.epam.services.UnPark;

@WebServlet(urlPatterns = "/choices")
public class ChoicesPage extends HttpServlet{
	@Override
	protected void doGet(final HttpServletRequest request,
            final HttpServletResponse response)
            throws IOException, ServletException {
		PrintWriter out = response.getWriter();
		out.println("<html>"
				+ "<body>"
				+ "<center><h3>Welcome admin!</h3></center>"
				+ "<form action='/choices' method='post'>"
				+ "<input type='radio' name='choice' value='park'/>Park vehicle"
				+ "<br/>"
				+ "<input type='radio' name='choice' value='unpark'/>Unpark vehicle"
				+ "<br/>"
				+ "Vehicle number:<input type='text' name='vehicleNumber' value=''/>"
				+ "<input type='submit' value='Submit'/>"
				+ "</body></html>");
		}
	@Override
	protected void doPost(final HttpServletRequest request,
            final HttpServletResponse response)
            throws IOException, ServletException {
		/** This hash map stores the vehicle number and the
	     *  slot that it is parked in. */
	    Map<String, Slot> occupiedVehicleNumberAndSlots =
	               new HashMap<>();
	    /** This array list stores the vacant slot numbers.  */
	    List<Integer> vacantSlotNumbers
	                         = new LinkedList<>();
	    final int ten = 10;
	    final int three = 3;
	    int numberOfSlots = ten;
	    findVacantSlots(vacantSlotNumbers,
	    		numberOfSlots, occupiedVehicleNumberAndSlots);
        Park parkObject = new Park();
        UnPark unParkObject = new UnPark();
        PrintWriter out = response.getWriter();
        out.println(request.getParameter("vehicleNumber"));
	}
    /** This method finds the vacant slots in the parking lot.
     * @param vacantSlotNumbers slot numbers of vacant slots in the parking lot.
     * @param numberOfSlots number of slots in the parking lot.
     * @param occupiedVehicleNumberAndSlots vehicle number - slot number
     */
    public void findVacantSlots(
             final List<Integer> vacantSlotNumbers,
             final int numberOfSlots, final Map<String,
             Slot> occupiedVehicleNumberAndSlots) {
    	TransactionOperations transactionOperations =
    			new TransactionOperations();
    	transactionOperations.readData(
                occupiedVehicleNumberAndSlots);
        int[] slotNumbers = new int[numberOfSlots];
        for (int index = 0; index < numberOfSlots; index++) {
            slotNumbers[index] = 0;
        }
        Collection<Slot> slotValues = occupiedVehicleNumberAndSlots.values();
        for (Slot slot : slotValues) {
            slotNumbers[(slot.getSlotNumber()) - 1] = 1;
        }
        for (int index = 0; index < numberOfSlots; index++) {
            if (slotNumbers[index] == 0) {
                vacantSlotNumbers.add(index + 1);
            }
        }
    }

}
