package com.epam.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/** web servlet.
 * @author Rithika_Mamidi
 */
@WebServlet(urlPatterns = "/adminLogin")
public class AdminLoginPage extends HttpServlet {
    /** displays the login page to admin.
     */
    @Override
    protected void doGet(final HttpServletRequest request,
            final HttpServletResponse response)
            throws IOException, ServletException {
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.print("<title>Admin login page</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1> <center>Hello admin! Enter your details</center></h1>");
    }

}
