package com.epam.parkingexceptions;
/** exception when parking lot is full.
 * @author Rithika_Mamidi
 */
public class ParkingLotFullException extends Exception {
    /** exception when parking lot is full.
     * @param exception exception string
     */
    public ParkingLotFullException(final String exception) {
        super(exception);
    }

}
