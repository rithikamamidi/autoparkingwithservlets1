package com.epam.parkingexceptions;
/** exception when parking lot is vacant.
 * @author Rithika_Mamidi
 */
public class ParkingLotVacantException extends Exception {
    /** exception when parking lot is vacant.
     * @param exception exception string
     */
    public ParkingLotVacantException(final String exception) {
        super(exception);
    }
}
