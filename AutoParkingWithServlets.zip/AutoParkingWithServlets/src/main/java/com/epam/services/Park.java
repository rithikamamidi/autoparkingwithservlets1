package com.epam.services;

import java.time.LocalTime;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.epam.parkingexceptions.InvalidVehicleNumberException;
import com.epam.parkingexceptions.ParkingLotFullException;
import com.epam.parkingexceptions.VehicleAlreadyInParkingLotException;
/** class contains all the methods required to park a vehicle.
 * @author Rithika_Mamidi
 */
public class Park {
    /** This method deals with the functionality when the vehicle is parked.
     * @param carNumber vehicle number of the vehicle
     * @param vacantSlotNumbers vacant slot numbers
     * @param occupiedVehicleNumberAndSlots vehicle number-slot number- inTime
     * @throws ParkingLotFullException when parking lot is full
     * @throws InvalidVehicleNumberException when vehicle number is invalid
     * @throws VehicleAlreadyInParkingLotException
     * when vehicle is already in parking lot.
     */
     public void park(final String carNumber,
            final List<Integer> vacantSlotNumbers,
            final Map<String, Slot> occupiedVehicleNumberAndSlots)
                    throws ParkingLotFullException,
                    InvalidVehicleNumberException,
                    VehicleAlreadyInParkingLotException {
        if (vacantSlotNumbers.isEmpty()) {
            throw new ParkingLotFullException("Parking lot is full !");
        } else {
            if (validateCarNumber(carNumber)) {
                parkCarAndStoreInTime(carNumber, vacantSlotNumbers,
                       occupiedVehicleNumberAndSlots);
            } else {
                throw new InvalidVehicleNumberException("Invalid car number !");
            }
        }
    }
     /** This method updates the data associated with
      *  the vehicle when it is parked.
      * @param carNumber  vehicle number to be parked
      * @param vacantSlotNumbers vacant slot numbers
      * @param occupiedVehicleNumberAndSlots vehicle number-slot number-intime
      * @throws VehicleAlreadyInParkingLotException
      * when vehicle is already in parking lot.*/
     public void parkCarAndStoreInTime(final String carNumber,
             final List<Integer> vacantSlotNumbers,
             final Map<String, Slot> occupiedVehicleNumberAndSlots)
                    throws VehicleAlreadyInParkingLotException {
         if (!occupiedVehicleNumberAndSlots.containsKey(carNumber)) {
             int slotNumber = ((LinkedList<Integer>) vacantSlotNumbers).
                    removeFirst();
             LocalTime inTime = LocalTime.now();
             Slot slot = new Slot(slotNumber, inTime);
             occupiedVehicleNumberAndSlots.put(carNumber, slot);
             TransactionOperations transactionFileOperations =
                     getTransactionOperationsObject();
             transactionFileOperations.append(carNumber, slotNumber, inTime);
             System.out.println("car parked successfully !");
         } else {
             throw new VehicleAlreadyInParkingLotException("Vehicle is "
                     + "already in parking lot !");
         }
     }
     /** This method validates the car number entered by the user.
      * @param vehicleNumber  Vehicle number entered
      * @return true if vehicle number is valid, else returns false. */
    public boolean validateCarNumber(final String vehicleNumber) {
        Validation validater = new Validation();
        return validater.validateVehicleNumber(vehicleNumber);
    }
    /** returns new Transaction operations object.
     * @return transaction file operations object.
     */
    public TransactionOperations getTransactionOperationsObject() {
       return new TransactionOperations();
    }


}
