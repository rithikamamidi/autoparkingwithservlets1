package com.epam.autoparking;



import static org.junit.Assert.assertEquals;

import java.time.LocalTime;




import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.epam.persistence.FileOperations;
import com.epam.services.LogOperations;
/** test class for log file operations class.
 * @author Rithika_Mamidi
 */
public class LogOperationsTest {
    /** object for Log file operations.
     */
    @InjectMocks
    private LogOperations logObject =
            new LogOperations();
    /** mock file operations.
     */
    @Mock
    private FileOperations mockFileOp;
    /** initialize all the variables needed for testing.
     */
    @Before
    public void init() {
        String fileNameForTest = "C:\\Users\\Rithika_Mamidi\\"
                + "eclipse-workspace\\Autoparking\\testlog.csv";
        logObject.setFileName(fileNameForTest);
    }
    /**test write method.
     */
    @Test
    public void testWrite() {
        logObject.write("AB15BB1234", 1, LocalTime.parse("12:00:00"),
                 LocalTime.parse("12:30:00"));
    }
    /** test get file name method.
     */
    @Test
    public void testGetFileName() {
        logObject.setFileName("abc.txt");
        assertEquals("abc.txt", logObject.getFileName());
    }

}
