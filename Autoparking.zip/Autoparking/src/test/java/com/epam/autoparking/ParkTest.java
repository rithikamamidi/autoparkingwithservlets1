package com.epam.autoparking;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.LinkedList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.epam.persistence.FileOperations;
import com.epam.services.Park;
import com.epam.services.Slot;
import com.epam.services.TransactionOperations;
/** test class for Park class.
 * @author Rithika_Mamidi
 */
public class ParkTest {
    /** This hashmap stores the vehicle number and the
     *  slot that it is parked in.
     */
    private HashMap<String, Slot> occupiedVehicleNumberAndSlots;
    /** This arraylist stores the vacant slot numbers.
     */
    private LinkedList<Integer> vacantSlotNumbers;
    /** create mock class object.
     */
    @Mock
    private TransactionOperations mockTransac;
    /** create mock class object.
     */
    @Mock
    private FileOperations mockFileOp;
    /** inject mocks into the class.
     */
    @InjectMocks
    private Park mockPark = new Park();
    /** init method initializes all the data structures
     *  required for testing other methods.
     */
    @Before
    public void init() {
        /** This hash map stores the vehicle number and the
         *  slot that it is parked in.
         */
         occupiedVehicleNumberAndSlots = new HashMap<String, Slot>();
        /** This array list stores the vacant slot numbers.
         */
         vacantSlotNumbers = new LinkedList<Integer>();
         vacantSlotNumbers.add(2);
         Slot slot = new Slot(1, LocalTime.now());
         occupiedVehicleNumberAndSlots.put("AB12BB1234", slot);
         MockitoAnnotations.initMocks(this);
    }

    /** test method for validateCarNumber() method.
     */
    @Test
    public void testValidateCarNumber() {
        Park parkObject = new Park();
        assertTrue(parkObject.validateCarNumber("AB12BB1234"));
        assertFalse(parkObject.validateCarNumber("ab12bb1234"));
    }
    /** test method for parkCarAndStoreInTime() method.
     * @throws Exception exception
     */
    @Test
    public void testParkCarAndStoreInTime() throws Exception {
        doNothing().when(mockTransac).append(anyString(),
               anyInt(), any(LocalTime.class));
        doNothing().when(mockFileOp).appendToFile(anyString(), anyString());
        mockPark.parkCarAndStoreInTime("AB24BB1234", vacantSlotNumbers,
               occupiedVehicleNumberAndSlots);
        assertEquals(2, occupiedVehicleNumberAndSlots.size());
    }
    /** test method for park() method.
     * @throws Exception exception
     */
    @Test
    public void testPark() throws Exception {
        doNothing().when(mockTransac).append(anyString(),
                anyInt(), any(LocalTime.class));
        doNothing().when(mockFileOp).appendToFile(anyString(), anyString());
        mockPark.park("AB40BB1234", vacantSlotNumbers,
                occupiedVehicleNumberAndSlots);
        mockPark.park("AB41BB1234", vacantSlotNumbers,
                occupiedVehicleNumberAndSlots);
        assertEquals(2, occupiedVehicleNumberAndSlots.size());
    }
    /** test method for park() method.
     * @throws Exception exception
     */
    @Test
    public void testParkExceptions() throws Exception {
        doNothing().when(mockTransac).append(anyString(),
                anyInt(), any(LocalTime.class));
        doNothing().when(mockFileOp).appendToFile(anyString(), anyString());
        mockPark.park("AB12BB1234", vacantSlotNumbers,
                occupiedVehicleNumberAndSlots);
        assertEquals(1, occupiedVehicleNumberAndSlots.size());
        mockPark.park("ab", vacantSlotNumbers,
                occupiedVehicleNumberAndSlots);
    }
}
