package com.epam.parkingexceptions;
/** exception when vehicle number searched for is already
 *  found in the parking lot.
 * @author Rithika_Mamidi
 */
public class VehicleAlreadyInParkingLotException extends Exception {
    /** exception when vehicle number searched for
     *  is already found in the parking lot.
     * @param exception exception string
     */
    public VehicleAlreadyInParkingLotException(final String exception) {
        super(exception);
    }

}
